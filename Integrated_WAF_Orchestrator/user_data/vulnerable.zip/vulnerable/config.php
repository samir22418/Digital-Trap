<?php
// Database configuration (vulnerable setup - no security)
$host = 'localhost';
$dbname = 'vulnerable_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// For SQLi demo, we'll use raw queries without prepared statements
?>